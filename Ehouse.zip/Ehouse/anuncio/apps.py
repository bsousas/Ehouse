from django.apps import AppConfig


class AnuncioConfig(AppConfig):
    name = 'anuncio'
