$(document).ready(function(){
    $('.slider').slider();
  });